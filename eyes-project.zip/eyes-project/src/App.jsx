import { useEffect, useRef, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Lights } from '@react-three/drei'
import * as faceLandmarksDetection from '@tensorflow-models/face-landmarks-detection'
import * as tf from '@tensorflow/tfjs'
import Eye from './components/Eye'
import Eyelid from './components/Eyelid'
import LoadingScreen from './components/LoadingScreen'
import BlinkDetector from './utils/BlinkDetector'
import EyeSmoothing from './utils/EyeSmoothing'
import './App.css'

function App() {
  const videoRef = useRef(null)
  const [pupilPosition, setPupilPosition] = useState({ x: 0, y: 0 })
  const [blinkState, setBlinkState] = useState(false)
  const [isModelLoaded, setIsModelLoaded] = useState(false)
  const [cameraPermission, setCameraPermission] = useState(null)
  
  const modelRef = useRef(null)
  const blinkDetectorRef = useRef(new BlinkDetector())
  const eyeSmoothingRef = useRef(new EyeSmoothing(0.4))
  const requestAnimationFrameIdRef = useRef(null)
  
  // Kamera başlatma
  useEffect(() => {
    const setupCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { 
            width: 640, 
            height: 480,
            facingMode: 'user' 
          },
          audio: false
        })
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream
          setCameraPermission(true)
        }
      } catch (error) {
        console.log('Kamera erişimi reddedildi:', error)
        setCameraPermission(false)
      }
    }
    
    setupCamera()
  }, [])
  
  // MediaPipe modeli yükleme
  useEffect(() => {
    const loadModel = async () => {
      try {
        const model = await faceLandmarksDetection.load(
          faceLandmarksDetection.SupportedPackages.mediapipeFacemesh
        )
        modelRef.current = model
        setIsModelLoaded(true)
      } catch (error) {
        console.error('Model yüklenirken hata:', error)
      }
    }
    
    loadModel()
  }, [])
  
  // Yüz tespiti ve göz takibi
  useEffect(() => {
    const detectFace = async () => {
      if (!modelRef.current || !videoRef.current || !cameraPermission) return
      
      try {
        const predictions = await modelRef.current.estimateFaces({
          input: videoRef.current,
          returnRawCoordinates: false,
        })
        
        if (predictions.length > 0) {
          const face = predictions[0]
          
          // Sol göz ve sağ göz landmark'ları
          const leftEye = face.annotations.leftEye
          const rightEye = face.annotations.rightEye
          
          // Göz merkezi hesapla
          if (leftEye && leftEye.length > 0 && rightEye && rightEye.length > 0) {
            const leftEyeCenter = {
              x: leftEye.reduce((sum, p) => sum + p[0], 0) / leftEye.length,
              y: leftEye.reduce((sum, p) => sum + p[1], 0) / leftEye.length
            }
            
            const rightEyeCenter = {
              x: rightEye.reduce((sum, p) => sum + p[0], 0) / rightEye.length,
              y: rightEye.reduce((sum, p) => sum + p[1], 0) / rightEye.length
            }
            
            // Video merkezi
            const videoCenter = {
              x: videoRef.current.videoWidth / 2,
              y: videoRef.current.videoHeight / 2
            }
            
            // Göz pozisyonunu normalleştir (-1 ile 1 arasında)
            const rawX = (leftEyeCenter.x - videoCenter.x) / (videoCenter.x * 0.5)
            const rawY = (leftEyeCenter.y - videoCenter.y) / (videoCenter.y * 0.5)
            
            // Yumuşat
            const smoothed = eyeSmoothingRef.current.smooth(rawX, rawY)
            setPupilPosition({ x: smoothed.x, y: -smoothed.y })
            
            // Kırpma tespiti
            const blinkResult = blinkDetectorRef.current.updateBlink(leftEye, rightEye)
            setBlinkState(blinkResult.blinkDetected)
          }
        }
        
        requestAnimationFrameIdRef.current = requestAnimationFrame(detectFace)
      } catch (error) {
        console.error('Yüz tespiti hatası:', error)
        requestAnimationFrameIdRef.current = requestAnimationFrame(detectFace)
      }
    }
    
    if (isModelLoaded) {
      detectFace()
    }
    
    return () => {
      if (requestAnimationFrameIdRef.current) {
        cancelAnimationFrame(requestAnimationFrameIdRef.current)
      }
    }
  }, [isModelLoaded, cameraPermission])
  
  return (
    <div className="app-container">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="camera-feed"
      />
      
      <Canvas camera={{ position: [0, 0, 2.5], fov: 50 }} className="canvas">
        <Lights />
        <OrbitControls 
          enableZoom={false}
          enablePan={false}
          autoRotate={!cameraPermission}
          autoRotateSpeed={2}
        />
        
        <group>
          <Eye pupilPosition={pupilPosition} />
          <Eyelid onBlink={blinkState} />
        </group>
        
        {!isModelLoaded && <LoadingScreen />}
      </Canvas>
      
      <div className="info-panel">
        <div className="status">
          {cameraPermission === null && <span>Kamera başlatılıyor...</span>}
          {cameraPermission === false && <span className="error">❌ Kamera erişimi reddedildi</span>}
          {cameraPermission === true && !isModelLoaded && <span>⏳ Model yükleniyor...</span>}
          {isModelLoaded && <span className="success">✅ Canlı takip aktif</span>}
        </div>
      </div>
    </div>
  )
}

export default App
